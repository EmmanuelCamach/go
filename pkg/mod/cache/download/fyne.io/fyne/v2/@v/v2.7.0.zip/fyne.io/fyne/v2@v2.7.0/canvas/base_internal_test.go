package canvas

import (
	"testing"

	"fyne.io/fyne/v2"

	"github.com/stretchr/testify/assert"
)

func TestBase_MinSize(t *testing.T) {
	base := &baseObject{}
	min := base.MinSize()

	assert.Positive(t, min.Width)
	assert.Positive(t, min.Height)
}

func TestBase_Move(t *testing.T) {
	base := &baseObject{}
	base.Move(fyne.NewPos(10, 10))
	pos := base.Position()

	assert.Equal(t, float32(10), pos.X)
	assert.Equal(t, float32(10), pos.Y)
}

func TestBase_Resize(t *testing.T) {
	base := &baseObject{}
	base.Resize(fyne.NewSize(10, 10))
	size := base.Size()

	assert.Equal(t, float32(10), size.Width)
	assert.Equal(t, float32(10), size.Height)
}

func TestBase_HideShow(t *testing.T) {
	base := &baseObject{}
	assert.True(t, base.Visible())

	base.Hide()
	assert.False(t, base.Visible())

	base.Show()
	assert.True(t, base.Visible())
}
